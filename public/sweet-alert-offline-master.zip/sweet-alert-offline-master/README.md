# sweet-alert-offline
sweet alert sin CDN para usarlo de forma local
# Implementación
#
<script src="/dist/sweetalert2.all.min.js"></script>
#
<link rel="stylesheet" href="/dist/sweetalert2.min.css">
#
<script src="/dist/sweetalert2.all.js"></script>
