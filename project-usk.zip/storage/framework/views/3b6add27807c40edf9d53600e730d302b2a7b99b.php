<!-- Menghubungkan dengan view template master -->

<?php $__env->startSection('judul', 'Halaman KK'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card bg-dark">
            <div class="card-body">
                <div class="table-responsive">
                    <table  class="table table-striped table-bordered table-dark" style="width: 100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Kode IK</th>
                                <th>PK Mentri</th>
                                <th>TW 1</th>
                                <th>TW 2</th>
                                <th>TW 3</th>
                                <th>TW 4</th>
                                <th>Bobot</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td ><?php echo e($x->id); ?></td>
                            <td>
                               <?php echo e($x->kode_ik); ?>

                            </td>
                            <td contenteditable="false"><?php echo e($x->pk_menteri); ?></td>
                            <td contenteditable="true"><?php echo e($x->tw_1); ?></td>
                            <td contenteditable="true"><?php echo e($x->tw_2); ?></td>
                            <td contenteditable="true"><?php echo e($x->tw_3); ?></td>
                            <td contenteditable="true"><?php echo e($x->tw_4); ?></td>
                            <td contenteditable="false"><?php echo e($x->bobot); ?></td>

                            <td>
                                <span class="del_btn"><i role="button" class="rounded bg-danger p-3 fa-solid fa-trash fa-sm"></i></span>
                                <span class="save_btn"><i role="button" class="rounded bg-info p-3 fa-solid fa-floppy-disk fa-sm"></i></span>
                                <span class="new_btn"><i role="button" class="rounded bg-success p-3 fa-solid fa-plus fa-sm"></i></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

 <?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('kk.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-usk\resources\views/kk/index.blade.php ENDPATH**/ ?>