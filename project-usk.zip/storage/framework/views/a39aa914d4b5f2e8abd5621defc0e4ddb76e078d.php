        <script>
            $(document).ready(function($){
                //add
                $(document).on('click', ".new_btn",function(e){
                    let row = $(this).closest('tr').clone();
                    $.each(row.find('td'), function(i1, v1){
                        $(this).html('')
                        if($(this).is(':nth-child(2)')){
                            $(this).html("<select name='kode_ik' type='text' id='kode_ik' class='d-inline form-control w-auto required'>  <?php $__currentLoopData = $IK; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataIK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($dataIK->kode_ik === $dataProgram->kode_ik): ?> <option value='<?php echo e($dataIK->kode_ik); ?>' selected='true'><?php echo e($dataIK->kode_ik); ?></option> <?php else: ?> <option value='<?php echo e($dataIK->kode_ik); ?>' ><?php echo e($dataIK->kode_ik); ?></option> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </select>")
                        }
                        if ($(this).is(':last-child')) {
                            $(this).html(' <span class="del_btn"><i role="button" class="rounded bg-danger py-3 px-2 fa-solid fa-trash fa-sm"></i></span> <span class="save_btn"><i role="button" class="rounded bg-info py-3 px-2 fa-solid fa-floppy-disk fa-sm"></i></span> <span class="new_btn"><i role="button" class="rounded bg-success py-3 px-2 fa-solid fa-plus fa-sm"></i></span>')
                        }
                    })

                    $(this).closest('tr').after(row);
                    // console.log(row[0].innerText);
                    // console.log($(this).closest('tr').after(row)[0].innerText.split("\t").slice(0, -1));
                    // console.log(row);
                })

                //save
                 $(document).on('click', ".save_btn",function(e){
                   let setiapBaris =  $(this).closest('tr')[0].innerText.split("\t").slice(0, -1)
                   let id = setiapBaris[0]
                   let kode_ik = $(this).closest('tr').find('select').val()
                   let kode_prog = setiapBaris[2]
                   let program = setiapBaris[3]

                      $.ajax({
                           type:'POST',
                           url:"<?php echo e(route('program.add')); ?>",
                           data:{
                             "_token": "<?php echo e(csrf_token()); ?>",
                             id,
                            kode_ik,
                            kode_prog,
                            program
                            },
                           success:function(data){
                             Swal.fire({
                                  title: 'DATA SUKSES TERSIMPAN',
                                  confirmButtonText: 'OK',
                                }).then((result) => {
                                   // Read more about isConfirmed, isDenied below
                                  if (result.isConfirmed) {
                                    location.reload()
                                  }
                                })

                           }
                        });
                })

                //del
                $(document).on('click', ".del_btn",function(e){
                    let setiapBaris =  $(this).closest('tr')[0].innerText.split("\t").slice(0, -1)
                       Swal.fire({
                              title: 'Data ini akan dihapus, apa anda yakin ?',
                              icon: 'warning',
                              showCancelButton: true,
                              confirmButtonColor: '#3085d6',
                              cancelButtonColor: '#d33',
                              confirmButtonText: 'Ya, Hapus data ini!'
                            }).then((result) => {
                              if (result.isConfirmed) {
                                 $.ajax({
                           type:'POST',
                           url:"<?php echo e(route('program.del')); ?>",
                           data:{
                             "_token": "<?php echo e(csrf_token()); ?>",
                            id:setiapBaris[0],
                            },
                           success:function(data){
                               Swal.fire({
                                  title: 'DATA SUKSES TERHAPUS',
                                  confirmButtonText: 'OK',
                                }).then((result) => {
                                  /* Read more about isConfirmed, isDenied below */
                                  if (result.isConfirmed) {
                                    location.reload()
                                  }
                                })
                              }
                            })
                           }
                        });


                })
            })
        </script>
<?php /**PATH C:\xampp\htdocs\project-usk\resources\views/program/script.blade.php ENDPATH**/ ?>