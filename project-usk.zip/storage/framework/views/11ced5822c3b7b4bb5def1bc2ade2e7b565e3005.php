<!-- Menghubungkan dengan view template master -->

<?php $__env->startSection('judul', 'Halaman RPK'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                            <tr>
                                <th>ID</th>
                                 <th>Kode IK</th>
                                 <th>Indikator Kinerja</th>
                                <th>Kode Program</th>
                                <th>Program</th>
                                <th>Rincian Program</th>
                                <th>Nama Kegiatan</th>
                                <th>TOR/KAK/ProposalProject</th>
                                <th>Kebutuhan Kegiatan</th>
                                <th>Rencana Jadwal Pelaksanaan</th>
                                <th>Tahun</th>
                                <th width="60%">Aksi</th>
                            </tr>
                        </thead>
                               <tbody>
                         <?php $__currentLoopData = $RPK; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataRPK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="attachment" class="item">
                            <td ><?php echo e($dataRPK->id); ?></td>
                            <td>
                                <select name="kode_ik" type="text" id="kode_ik" class="kode_ik d-inline form-control w-auto required">
                                <option value="SILAHKAN PILIH" >SILAHKAN PILIH</option>
                                <?php $__currentLoopData = $KK; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($dataKK->kode_ik === $dataRPK->kode_ik): ?>
                                        <option value="<?php echo e($dataKK->kode_ik); ?>" selected="true"><?php echo e($dataKK->kode_ik); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($dataKK->kode_ik); ?>" ><?php echo e($dataKK->kode_ik); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td class="indikator_kinerja"></td>
                            <td>
                                <select name="kode_prog" class="kode_prog form-control d-inline w-auto required" id=""></select>
                            </td>
                            <td class="program"></td>
                            <td>
                                <select name="rincian_program" type="text" id="rincian_program" class="rincian_program d-inline form-control w-auto required">
                                <option value="SILAHKAN PILIH" >SILAHKAN PILIH</option>
                                <?php $__currentLoopData = $RINCIANPROGRAM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataMAK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($dataMAK->MAK === $dataRPK->rincian_program): ?>
                                        <option value="<?php echo e($dataMAK->MAK); ?>" selected="true"><?php echo e($dataMAK->MAK); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($dataMAK->MAK); ?>" ><?php echo e($dataMAK->MAK); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td contenteditable="true"><?php echo e($dataRPK->nama_kegiatan); ?></td>
                            <td>
                                <div id="uploadStatus"></div>
                               <form id="uploadForm" enctype="multipart/form-data">
                                  <input type="file" class="fu" name="file" id="fileInput">
                                  <input id="submit" type="submit">submit</input>
                                </form>
                            </td>
                            <td contenteditable="true"><?php echo e($dataRPK->Kebutuhan_Kegiatan); ?></td>
                            <td>
                                <select name="Rencana_Jadwal_Pelaksanaan" class="Rencana_Jadwal_Pelaksanaan d-inline form-control w-auto required">
                                    <option value="TRIWULAN 1">TRIWULAN 1</option>
                                    <option value="TRIWULAN 2">TRIWULAN 2</option>
                                    <option value="TRIWULAN 3">TRIWULAN 3</option>
                                    <option value="TRIWULAN 4">TRIWULAN 4</option>
                                </select>
                            </td>
                            <td>
                                <select name="tahun" class="tahun d-inline form-control w-auto required">
                                    <option value="PILIH TAHUN">PILIH TAHUN</option>
                                    <option value="2022">2022</option>
                                    <option value="2023">2023</option>
                                    <option value="2025">2024</option>
                                    <option value="2025">2025</option>
                                    <option value="2026">2026</option>
                                </select>
                            </td>
                            <td>
                                 <span class="del_btn"><i role="button" class="rounded bg-danger py-3 px-2 fa-solid fa-trash fa-sm"></i></span>
                                <span class="save_btn"><i role="button" class="rounded bg-info py-3 px-2 fa-solid fa-floppy-disk fa-sm"></i></span>
                                <span class="new_btn"><i role="button" class="rounded bg-success py-3 px-2 fa-solid fa-plus fa-sm"></i></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                            </table>
                        </div>
                    </div>
                </div>

<?php $__env->stopSection(); ?>

 <?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('rpk.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-usk\resources\views/rpk/index.blade.php ENDPATH**/ ?>