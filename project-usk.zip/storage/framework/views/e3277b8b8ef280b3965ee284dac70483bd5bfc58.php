 <!-- Required meta tags -->
 <meta charset="utf-8">
 <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <!--favicon-->
 <link rel="icon" href="assets/images/favicon-32x32.png" type="image/png" />
 <!--plugins-->
 <link href="<?php echo asset('assets/'); ?>/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
 <link href="<?php echo asset('assets/'); ?>/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
 <link href="<?php echo asset('assets/'); ?>/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
 <link href="<?php echo asset('assets/'); ?>/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />

 <!-- loader-->
 

 <!-- Bootstrap CSS -->
 <link href="<?php echo asset('assets/'); ?>/css/bootstrap.min.css" rel="stylesheet">
 <link href="<?php echo asset('assets/'); ?>/css/bootstrap-extended.css" rel="stylesheet">
 <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&amp;display=swap" rel="stylesheet">
 <link href="<?php echo asset('assets/'); ?>/css/app.css" rel="stylesheet">
 <link href="<?php echo asset('assets/'); ?>/css/icons.css" rel="stylesheet">


 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
 

 
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
 

 <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@900&display=swap" rel="stylesheet">


<style>
table tr{
  color: white;
}
.card{
    background-color: #3D373F;
    color: white;
  }

</style>



 <?php echo $__env->yieldPushContent('styles'); ?>
 <title><?php echo $__env->yieldContent('title'); ?></title>
<?php /**PATH C:\xampp\htdocs\project-usk\resources\views/layouts/head.blade.php ENDPATH**/ ?>