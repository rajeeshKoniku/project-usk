<div class="mb-3 row">
    <label for="<?php echo e($name); ?>" class="col-sm-2 col-form-label"><?php echo e($value); ?></label>
    <div class="col-sm-10">
        <input type="<?php echo e($type); ?>" class="form-control-plaintext bg-light text-light px-2" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" required>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\project-usk\resources\views/components/input.blade.php ENDPATH**/ ?>