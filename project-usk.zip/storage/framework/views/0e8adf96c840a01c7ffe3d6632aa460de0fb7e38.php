<script type="text/javascript">
    $(document).ready(function() {


        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // fetch/ambil data datatable
        $('#tabelKegiatan').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [],
            "ajax": "<?php echo e(route('RincianKomponen.fetch_data')); ?>",
            columns: [{
                    data: "id",
                    name: "id",
                    className: "hide_column"
                },
                {
                    data: "Keg",
                    name: "Keg",
                },
                {
                    data: "KRO",
                    name: "KRO",
                },
                {
                    data: "RO",
                    name: "RO",
                },
                {
                    data: "KP",
                    name: "KP",
                },
                {
                    data: "SK",
                    name: "SK",
                },
                {
                    data: "Sub_Komponen",
                    name: "Sub_Komponen",
                },
                
            ],
            dom: 'Bflrtip',
            buttons: [{
                text: 'Tambah',
                action: function(e, dt, node, config) {
                    $('#tambahModal').modal('show')
                }
            }, 'copy', 'excel', 'pdf']
        });

        // saat draw tabel, jalankan tabledit
        $('#tabelKegiatan').on('draw.dt', function() {
            $('#tabelKegiatan').Tabledit({
                url: "<?php echo e(route('RincianKomponen.action')); ?>",
                dataType: "json",
                // eventType: 'dblclick',
                // editButton: false,
                columns: {
                    identifier: [0, 'id'],
                    editable: [
                        [1, 'Keg'],
                        [2, 'KRO'],
                        [3, 'RO'],
                        [4, 'KP'],
                        [5, 'SK'],
                        [6, 'Sub_Komponen', '{"rows": "5", "maxlength": "255", "wrap": "hard"}'],
                    ]
                },
                restoreButton: false,
                buttons: {
                    edit: {
                        class: 'btn btn-sm btn-success m-1',
                        html: '<span class="lni lni-pencil"></span>',
                        action: 'edit'
                    },
                    delete: {
                        class: 'btn btn-sm btn-danger m-1',
                        html: '<span class="lni lni-trash"></span>',
                        action: 'delete'
                    },
                    save: {
                        class: 'btn btn-sm btn-success',
                        html: 'Save'
                    },
                    restore: {
                        class: 'btn btn-sm btn-warning',
                        html: 'Restore',
                        action: 'restore'
                    },
                    confirm: {
                        class: 'btn btn-sm btn-danger',
                        html: 'Confirm'
                    }
                },
                onSuccess: function(data, textStatus, jqXHR) {
                    // console.log(data, textStatus, jqXHR);
                    // jika aksi hapus maka hapus data dari baris dan reload tabelKegiatan
                    if (data.action == 'delete') {
                        $('#' + data.id).remove()
                        $('#tabelKegiatan').DataTable().ajax.reload();
                    }
                },
            });
        });

        //////////////// tambah program ////////////////////////
        $('#form').submit(function(e) {
            e.preventDefault();

            let Keg = $('#Keg').val();
            let KRO = $('#KRO').val();
            let RO = $('#RO').val();
            let KP = $('#KP').val();
            let SK = $('#SK').val();
            let Sub_Komponen = $('#Sub_Komponen').val();

            $.ajax({
                url: "<?php echo e(route('RincianKomponen.store')); ?>",
                type: 'POST',
                data: {
                    Keg,
                    KRO,
                    RO,
                    KP,
                    SK,
                    Sub_Komponen
                },
                success: function(data) {
                    // console.log(data);
                    $('#Keg').val('');
                    $('#KRO').val('');
                    $('#RO').val('');
                    $('#KP').val('');
                    $('#SK').val('');
                    $('#Sub_Komponen').val('');

                    // setelah berhasil, reload tabelKegiatan
                    $('#tabelKegiatan').DataTable().ajax.reload();
                    $('#tambahModal').modal('hide');
                }
            });

        })
    });
</script>
<?php /**PATH C:\xampp\htdocs\project-usk\resources\views/RincianKomponen/script.blade.php ENDPATH**/ ?>