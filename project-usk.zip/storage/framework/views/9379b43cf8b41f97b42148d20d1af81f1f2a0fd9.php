<!-- Menghubungkan dengan view template master -->

<?php $__env->startSection('judul', 'Halaman Rincian Program'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card bg-dark">
            <div class="card-body">
                <div class="table-responsive">
                    <table  class="table table-striped table-bordered table-dark" style="width: 100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Keg</th>
                                <th>KRO</th>
                                <th>RO</th>
                                <th>KP</th>
                                <th>SK</th>
                                <th>Klasifikasi Penganggaran</th>
                                <th>CODEBASE</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td ><?php echo e($x->id_kegiatan); ?></td>
                            <td contenteditable="true"><?php echo e($x->Keg); ?></td>
                            <td contenteditable="true"><?php echo e($x->KRO); ?></td>
                            <td contenteditable="true"><?php echo e($x->RO); ?></td>
                            <td contenteditable="true"><?php echo e($x->KP); ?></td>
                            <td contenteditable="true"><?php echo e($x->SK); ?></td>
                            <td contenteditable="true"><?php echo e($x->MAK); ?></td>
                            <td contenteditable="FALSE"><?php echo e($x->CODEBASE); ?></td>
                            <td>
                                <span class="del_btn"><i role="button" class="rounded bg-danger py-3 px-2 fa-solid fa-trash fa-sm"></i></span>
                                <span class="save_btn"><i role="button" class="rounded bg-info py-3 px-2 fa-solid fa-floppy-disk fa-sm"></i></span>
                                <span class="new_btn"><i role="button" class="rounded bg-success py-3 px-2 fa-solid fa-plus fa-sm"></i></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

 <?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('rincianprogram.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-usk\resources\views/rincianprogram/index.blade.php ENDPATH**/ ?>