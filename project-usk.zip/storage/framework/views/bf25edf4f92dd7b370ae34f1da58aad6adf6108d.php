<div class="mb-3 row">
    <label for="<?php echo e($name); ?>" class="col-sm-2 col-form-label"><?php echo e($value); ?></label>
    <div class="col-sm-10">
        <select class="form-select text-dark" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" required>
            <?php echo e($slot); ?>

        </select>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\project-usk\resources\views/components/select.blade.php ENDPATH**/ ?>