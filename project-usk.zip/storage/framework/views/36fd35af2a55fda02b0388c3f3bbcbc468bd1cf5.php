<ul class="metismenu" id="menu">
    <li>
        <a href="javascript:;" class="has-arrow">
            <div class="parent-icon"><i class="bx bx-category"></i>
            </div>
            <div class="menu-title">Data Center</div>
        </a>
        <ul>
            <li> <a href="<?php echo e(route('ss.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Sasaran</a></li>
            <li> <a href="<?php echo e(route('ik.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Iku</a></li>
            <li> <a href="<?php echo e(route('program.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Program</a></li>
            <li> <a href="<?php echo e(route('kkmentri.index')); ?>"><i class="bx bx-right-arrow-alt"></i>KK Mentri</a></li>
            <li> <a href="<?php echo e(route('rincianprogram.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Rancangan Anggaran</a></li>
            
        </ul>
    </li>

    <li>
        <a href="javascript:;" class="has-arrow">
            <div class="parent-icon"><i class="bx bx-category"></i>
            </div>
            <div class="menu-title">Create Data</div>
        </a>
        <ul>
             
        <a href="<?php echo e(route('kk.index')); ?>">
            <div class="parent-icon"><i class='bx bx-grid'></i>
            </div>
            <div class="menu-title">Perjanjian Kinerja</div>
        </a>
        <a href="<?php echo e(route('rpk.index')); ?>">
            <div class="parent-icon"><i class='bx bx-grid'></i>
            </div>
            <div class="menu-title">Rencana Program Kegiatan</div>
        </a>
        <a href="<?php echo e(route('rab.index')); ?>">
            <div class="parent-icon"><i class='bx bx-grid'></i>
            </div>
            <div class="menu-title">Rincian Anggaran Biaya</div>
        </a>
        <a href="<?php echo e(route('kk.index')); ?>">
            <div class="parent-icon"><i class='bx bx-grid'></i>
            </div>
            <div class="menu-title">Rancangan Anggaran</div>
        </a>
        </ul>
    </li>

    
    <li>
        <a href="javascript:;" class="has-arrow">
            <div class="parent-icon"><i class="bx bx-category"></i>
            </div>
            <div class="menu-title">Laporan</div>
        </a>
        <ul>
        <a href="<?php echo e(route('kk.index')); ?>">
            <div class="parent-icon"><i class='bx bx-grid'></i>
            </div>
            <div class="menu-title">Realita</div>
        </a>
        <a href="<?php echo e(route('kk.index')); ?>">
            <div class="parent-icon"><i class='bx bx-grid'></i>
            </div>
            <div class="menu-title">PERKIN</div>
        </a>
        <a href="<?php echo e(route('kk.index')); ?>">
            <div class="parent-icon"><i class='bx bx-grid'></i>
            </div>
            <div class="menu-title">REKAT</div>
        </a>
        <a href="<?php echo e(route('kk.index')); ?>">
            <div class="parent-icon"><i class='bx bx-grid'></i>
            </div>
            <div class="menu-title">RAB</div>
        </a>
        <a href="<?php echo e(route('kk.index')); ?>">
            <div class="parent-icon"><i class='bx bx-grid'></i>
            </div>
            <div class="menu-title">RANGKA</div>
        </a>
        </ul>
    </li>

        
    </li>
</ul>
<?php /**PATH C:\xampp\htdocs\project-usk\resources\views/layouts/sideBarNavigation.blade.php ENDPATH**/ ?>