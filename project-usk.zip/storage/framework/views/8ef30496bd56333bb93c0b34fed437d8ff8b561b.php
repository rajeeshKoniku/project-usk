<script src="<?php echo asset('assets/'); ?>/js/jquery.min.js"></script>
<!-- Bootstrap JS -->
<script src="<?php echo asset('assets/'); ?>/js/bootstrap.bundle.min.js"></script>

<!--plugins-->
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo asset('assets/'); ?>/plugins/simplebar/js/simplebar.min.js"></script>
<script src="<?php echo asset('assets/'); ?>/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="<?php echo asset('assets/'); ?>/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="<?php echo asset('assets/'); ?>/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
<script src="<?php echo asset('assets/'); ?>/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo asset('assets/'); ?>/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script src="<?php echo asset('assets/'); ?>/plugins/jquery-tabledit-1.2.7/jquery.tabledit.min.js"></script>

<!--app JS-->
<script src="<?php echo asset('assets/'); ?>/js/app.js"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\xampp\htdocs\project-usk\resources\views/layouts/footer.blade.php ENDPATH**/ ?>