<!-- Menghubungkan dengan view template master -->

<?php $__env->startSection('judul', 'Halaman Program'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card bg-dark">
            <div class="card-body">
                <div class="table-responsive">
                    <table  class="table table-striped table-bordered table-dark" style="width: 100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Kode IKU</th>
                                <th>Kode Program</th>
                                <th>Program</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                         <?php $__currentLoopData = $Program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataProgram): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td ><?php echo e($dataProgram->id); ?></td>
                            <td >
                                <select name="kode_ik" type="text" id="kode_ik" class="d-inline form-control w-auto required">
                                <?php $__currentLoopData = $IK; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataIK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($dataIK->kode_ik === $dataProgram->kode_ik): ?>
                                        <option value="<?php echo e($dataIK->kode_ik); ?>" selected="true"><?php echo e($dataIK->kode_ik); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($dataIK->kode_ik); ?>" ><?php echo e($dataIK->kode_ik); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td contenteditable="true"><?php echo e($dataProgram->kode_prog); ?></td>
                            <td contenteditable="true"><?php echo e($dataProgram->program); ?></td>
                            <td style="column-width: 200px;">
                                <span class="del_btn"><i role="button" class="rounded bg-danger py-3 px-2 fa-solid fa-trash fa-sm"></i></span>
                                <span class="save_btn"><i role="button" class="rounded bg-info py-3 px-2 fa-solid fa-floppy-disk fa-sm"></i></span>
                                <span class="new_btn"><i role="button" class="rounded bg-success py-3 px-2 fa-solid fa-plus fa-sm"></i></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

 <?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('program.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-usk\resources\views/Program/index.blade.php ENDPATH**/ ?>