<!-- Menghubungkan dengan view template master -->

<?php $__env->startSection('judul', 'Halaman IK'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card bg-dark">
            <div class="card-body">
                <div class="table-responsive">
                    <table  class="table table-striped table-bordered table-dark" style="width: 100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Kode SS</th>
                                <th>Kode IK</th>
                                <th>Indikator Kinerja</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                         <?php $__currentLoopData = $IK; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataIK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td ><?php echo e($dataIK->id); ?></td>
                            <td>
                                <select name="kode_ss" type="text" id="kode_ss" class="d-inline form-control w-auto required">
                                <?php $__currentLoopData = $SS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataSS): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($dataSS->kode_ss === $dataIK->ss_id): ?>
                                        <option value="<?php echo e($dataSS->kode_ss); ?>" selected="true"><?php echo e($dataSS->kode_ss); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($dataSS->kode_ss); ?>" ><?php echo e($dataSS->kode_ss); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td contenteditable="true"><?php echo e($dataIK->kode_ik); ?></td>
                            <td contenteditable="true"><?php echo e($dataIK->indikator_kinerja); ?></td>

                            <td>
                                <span class="del_btn"><i role="button" class="rounded bg-danger py-3 px-2 fa-solid fa-trash fa-sm"></i></span>
                                <span class="save_btn"><i role="button" class="rounded bg-info py-3 px-2 fa-solid fa-floppy-disk fa-sm"></i></span>
                                <span class="new_btn"><i role="button" class="rounded bg-success py-3 px-2 fa-solid fa-plus fa-sm"></i></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

 <?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('ik.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-usk\resources\views/ik/index.blade.php ENDPATH**/ ?>